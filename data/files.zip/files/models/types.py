from enum import Enum


class BaseModelType(str, Enum):
    Any = "any"  # For models that are not associated with any particular base model.
    StableDiffusion1 = "sd-1"
    StableDiffusion2 = "sd-2"
    StableDiffusionXL = "sdxl"
    StableDiffusionXLRefiner = "sdxl-refiner"


class LoRAModelFormat(str, Enum):
    LyCORIS = "lycoris"
    Diffusers = "diffusers"
