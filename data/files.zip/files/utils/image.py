import base64
import random
import requests
from io import BytesIO
from PIL import Image
from utils.common import timing_decorator
from utils.config import settings


@timing_decorator
def get_base64_from_pil_image(image: Image.Image, format: str = settings.default_image_format) -> str:
    buffered = BytesIO()
    image.save(buffered, format=format, quality=100)
    image_bytes = buffered.getvalue()
    return base64.b64encode(image_bytes).decode("utf-8")


@timing_decorator
def get_pil_image_from_base64(base64_string: str) -> Image.Image:
    return Image.open(BytesIO(base64.b64decode(base64_string))).convert("RGB")


@timing_decorator
def save_image_from_base64(base64_string: str, path: str) -> None:
    image = get_pil_image_from_base64(base64_string)
    image.save(path)


@timing_decorator
def get_pil_image_from_url(url: str, to_gray: bool = False) -> Image.Image:
    if to_gray:
        return Image.open(requests.get(url, stream=True).raw).convert("L")
    return Image.open(requests.get(url, stream=True).raw).convert("RGB")
