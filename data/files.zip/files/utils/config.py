import os
from functools import lru_cache
from pydantic import BaseSettings
from custom.schema.payloads.base import GPUTypes


class Settings(BaseSettings):
    gpu_type: GPUTypes
    default_image_format: str
    models_path: str
    fooocus_patch_weights_path: str
    fooocus_head_model_path: str
    unet2diffusers_map_path: str
    control_net_models_path: str
    adapter_models_path: str
    textual_inversion_path: str
    character_lora_path: str
    style_lora_path: str

    class Config:
        env_file = ".env"


@lru_cache
def get_settings():
    return Settings()