import copy
import cv2
import gc
import json
import logging
import numpy as np
import torch
from enum import Enum
from PIL import Image, ImageFilter, ImageOps
from custom.schema.common import ResizeModeTypes
from custom.utils import checkpoint_pickle, model_management
import os

logger = logging.getLogger(__name__)
ROOT_DIR = os.path.abspath(os.path.dirname(__file__))

def flatten(img, bgcolor):
    """
    Replaces transparency with bgcolor (example: "#ffffff"), returning an RGB mode image with no transparency.
    Args:
        img (PIL.Image): The input image.
        bgcolor (str): The background color to replace transparency with.

    Returns:
        PIL.Image: The flattened image.
    """
    if img.mode == "RGBA":
        background = Image.new("RGBA", img.size, bgcolor)
        background.paste(img, mask=img)
        img = background

    return img.convert("RGB")


def get_crop_region(mask, pad=0):
    """
    Finds a rectangular region that contains all masked areas in an image.
    Args:
        mask (numpy.ndarray): The mask image.
        pad (int): The padding to be added to the crop region.

    Returns:
        tuple: The (x1, y1, x2, y2) coordinates of the rectangle.
    """
    h, w = mask.shape

    crop_left = 0
    for i in range(w):
        if not (mask[:, i] == 0).all():
            break
        crop_left += 1

    crop_right = 0
    for i in reversed(range(w)):
        if not (mask[:, i] == 0).all():
            break
        crop_right += 1

    crop_top = 0
    for i in range(h):
        if not (mask[i] == 0).all():
            break
        crop_top += 1

    crop_bottom = 0
    for i in reversed(range(h)):
        if not (mask[i] == 0).all():
            break
        crop_bottom += 1

    return (
        int(max(crop_left - pad, 0)),
        int(max(crop_top - pad, 0)),
        int(min(w - crop_right + pad, w)),
        int(min(h - crop_bottom + pad, h)),
    )


def expand_crop_region(crop_region, processing_width, processing_height, image_width, image_height):
    """
    Expands the crop region obtained from `get_crop_region()` to match the ratio of the image the region will be processed in.
    Args:
        crop_region (tuple): The crop region coordinates obtained from `get_crop_region()`.
        processing_width (int): The width of the processing image.
        processing_height (int): The height of the processing image.
        image_width (int): The width of the original image.
        image_height (int): The height of the original image.

    Returns:
        tuple: The expanded region coordinates.
    """

    x1, y1, x2, y2 = crop_region

    ratio_crop_region = (x2 - x1) / (y2 - y1)
    ratio_processing = processing_width / processing_height

    if ratio_crop_region > ratio_processing:
        desired_height = (x2 - x1) / ratio_processing
        desired_height_diff = int(desired_height - (y2 - y1))
        y1 -= desired_height_diff // 2
        y2 += desired_height_diff - desired_height_diff // 2
        if y2 >= image_height:
            diff = y2 - image_height
            y2 -= diff
            y1 -= diff
        if y1 < 0:
            y2 -= y1
            y1 -= y1
        if y2 >= image_height:
            y2 = image_height
    else:
        desired_width = (y2 - y1) * ratio_processing
        desired_width_diff = int(desired_width - (x2 - x1))
        x1 -= desired_width_diff // 2
        x2 += desired_width_diff - desired_width_diff // 2
        if x2 >= image_width:
            diff = x2 - image_width
            x2 -= diff
            x1 -= diff
        if x1 < 0:
            x2 -= x1
            x1 -= x1
        if x2 >= image_width:
            x2 = image_width

    return x1, y1, x2, y2


def fill(image, mask):
    """Fills masked regions with colors from the image using blur. Not extremely effective.

    Args:
        image (PIL.Image.Image): The input image.
        mask (PIL.Image.Image): The mask image representing the areas to be filled.

    Returns:
        PIL.Image.Image: The modified image with filled regions.
    """

    image_mod = Image.new("RGBA", (image.width, image.height))

    image_masked = Image.new("RGBa", (image.width, image.height))
    image_masked.paste(image.convert("RGBA").convert("RGBa"), mask=ImageOps.invert(mask.convert("L")))

    image_masked = image_masked.convert("RGBa")

    for radius, repeats in [(256, 1), (64, 1), (16, 2), (4, 4), (2, 2), (0, 1)]:
        blurred = image_masked.filter(ImageFilter.GaussianBlur(radius)).convert("RGBA")
        for _ in range(repeats):
            image_mod.alpha_composite(blurred)

    return image_mod.convert("RGB")


def resize(img, w, h):
    """Resizes an image to the specified width and height.

    Args:
        img (PIL.Image.Image): The input image.
        w (int): The target width.
        h (int): The target height.

    Returns:
        PIL.Image.Image: The resized image.
    """
    return img.resize((w, h), resample=Image.LANCZOS)


def resize_images(resize_mode, im, width, height):
    """Resizes an image based on the specified mode and dimensions.

    Args:
        resize_mode (int): The resize mode.
            - 0: Resize and maintain aspect ratio.
            - 1: Resize and crop to fill the specified dimensions while maintaining aspect ratio.
            - 2: Resize and pad to fill the specified dimensions while maintaining aspect ratio.
        im (PIL.Image.Image): The input image.
        width (int): The target width.
        height (int): The target height.

    Returns:
        PIL.Image.Image: The resized image.
    """
    print(resize_mode, type(im), width, height)
    
    if resize_mode == ResizeModeTypes.JUST_RESIZE:
        res = resize(im, width, height)
    elif resize_mode == ResizeModeTypes.CROP_AND_RESIZE:
        ratio = width / height
        src_ratio = im.width / im.height

        src_w = width if ratio > src_ratio else im.width * height // im.height
        src_h = height if ratio <= src_ratio else im.height * width // im.width

        resized = resize(im, src_w, src_h)
        res = Image.new("RGB", (width, height))
        res.paste(resized, box=(width // 2 - src_w // 2, height // 2 - src_h // 2))
    elif resize_mode == ResizeModeTypes.RESIZE_AND_FILL:
        ratio = width / height
        src_ratio = im.width / im.height

        src_w = width if ratio < src_ratio else im.width * height // im.height
        src_h = height if ratio >= src_ratio else im.height * width // im.width

        resized = resize(im, src_w, src_h)
        res = Image.new("RGB", (width, height))
        res.paste(resized, box=(width // 2 - src_w // 2, height // 2 - src_h // 2))

        if ratio < src_ratio:
            fill_height = height // 2 - src_h // 2
            res.paste(resized.resize((width, fill_height), box=(0, 0, width, 0)), box=(0, 0))
            res.paste(
                resized.resize((width, fill_height), box=(0, resized.height, width, resized.height)),
                box=(0, fill_height + src_h),
            )
        elif ratio > src_ratio:
            fill_width = width // 2 - src_w // 2
            res.paste(resized.resize((fill_width, height), box=(0, 0, 0, height)), box=(0, 0))
            res.paste(
                resized.resize((fill_width, height), box=(resized.width, 0, resized.width, height)),
                box=(fill_width + src_w, 0),
            )
    else:
        raise ValueError(f"Invalid resize mode: {resize_mode}")
    return res


def masking_fill(image, mask):
    """Fills masked regions with colors from the image using blur. Not extremely effective.

    Args:
        image (PIL.Image.Image): The input image.
        mask (PIL.Image.Image): The mask image representing the areas to be filled.

    Returns:
        PIL.Image.Image: The modified image with filled regions.
    """

    image_mod = Image.new("RGBA", (image.width, image.height))

    image_masked = Image.new("RGBa", (image.width, image.height))
    image_masked.paste(image.convert("RGBA").convert("RGBa"), mask=ImageOps.invert(mask.convert("L")))

    image_masked = image_masked.convert("RGBa")

    for radius, repeats in [(256, 1), (64, 1), (16, 2), (4, 4), (2, 2), (0, 1)]:
        blurred = image_masked.filter(ImageFilter.GaussianBlur(radius)).convert("RGBA")
        for _ in range(repeats):
            image_mod.alpha_composite(blurred)

    return image_mod.convert("RGB")


def apply_overlay(image, paste_loc, index, overlays):
    """Applies an overlay image onto another image at a specified location.

    Args:
        image (PIL.Image.Image): The base image.
        paste_loc (tuple): The (x, y, w, h) coordinates specifying where to paste the overlay.
        index (int): The index of the overlay image.
        overlays (list): A list of overlay images.

    Returns:
        PIL.Image.Image: The modified image with the overlay applied.
    """

    if overlays is None or index >= len(overlays):
        return image

    overlay = overlays[index]

    if paste_loc is not None:
        x, y, w, h = paste_loc
        base_image = Image.new("RGBA", (overlay.width, overlay.height))
        image = resize_images(ResizeModeTypes.CROP_AND_RESIZE, image, w, h)
        base_image.paste(image, (x, y))
        image = base_image

    image = image.convert("RGBA")
    image.alpha_composite(overlay)
    image = image.convert("RGB")

    return image


def get_unique_axis0(data):
    arr = np.asanyarray(data)
    idxs = np.lexsort(arr.T)
    arr = arr[idxs]
    unique_idxs = np.empty(len(arr), dtype=np.bool_)
    unique_idxs[:1] = True
    unique_idxs[1:] = np.any(arr[:-1, :] != arr[1:, :], axis=-1)
    return arr[unique_idxs]


# High Quality Edge Thinning using Pure Python
# Written by Lvmin Zhang
# 2023 April
# Stanford University
# If you use this, please Cite "High Quality Edge Thinning using Pure Python", Lvmin Zhang, In Mikubill/sd-webui-controlnet.


lvmin_kernels_raw = [
    np.array([[-1, -1, -1], [0, 1, 0], [1, 1, 1]], dtype=np.int32),
    np.array([[0, -1, -1], [1, 1, -1], [0, 1, 0]], dtype=np.int32),
]

lvmin_kernels = []
lvmin_kernels += [np.rot90(x, k=0, axes=(0, 1)) for x in lvmin_kernels_raw]
lvmin_kernels += [np.rot90(x, k=1, axes=(0, 1)) for x in lvmin_kernels_raw]
lvmin_kernels += [np.rot90(x, k=2, axes=(0, 1)) for x in lvmin_kernels_raw]
lvmin_kernels += [np.rot90(x, k=3, axes=(0, 1)) for x in lvmin_kernels_raw]

lvmin_prunings_raw = [
    np.array([[-1, -1, -1], [-1, 1, -1], [0, 0, -1]], dtype=np.int32),
    np.array([[-1, -1, -1], [-1, 1, -1], [-1, 0, 0]], dtype=np.int32),
]

lvmin_prunings = []
lvmin_prunings += [np.rot90(x, k=0, axes=(0, 1)) for x in lvmin_prunings_raw]
lvmin_prunings += [np.rot90(x, k=1, axes=(0, 1)) for x in lvmin_prunings_raw]
lvmin_prunings += [np.rot90(x, k=2, axes=(0, 1)) for x in lvmin_prunings_raw]
lvmin_prunings += [np.rot90(x, k=3, axes=(0, 1)) for x in lvmin_prunings_raw]


def remove_pattern(x, kernel):
    objects = cv2.morphologyEx(x, cv2.MORPH_HITMISS, kernel)
    objects = np.where(objects > 127)
    x[objects] = 0
    return x, objects[0].shape[0] > 0


def thin_one_time(x, kernels):
    y = x
    is_done = True
    for k in kernels:
        y, has_update = remove_pattern(y, k)
        if has_update:
            is_done = False
    return y, is_done


def lvmin_thin(x, prunings=True):
    y = x
    for i in range(32):
        y, is_done = thin_one_time(y, lvmin_kernels)
        if is_done:
            break
    if prunings:
        y, _ = thin_one_time(y, lvmin_prunings)
    return y


def make_nms(x):
    f1 = np.array([[0, 0, 0], [1, 1, 1], [0, 0, 0]], dtype=np.uint8)
    f2 = np.array([[0, 1, 0], [0, 1, 0], [0, 1, 0]], dtype=np.uint8)
    f3 = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=np.uint8)
    f4 = np.array([[0, 0, 1], [0, 1, 0], [1, 0, 0]], dtype=np.uint8)
    y = np.zeros_like(x)
    for f in [f1, f2, f3, f4]:
        np.putmask(y, cv2.dilate(x, kernel=f) == x, x)
    return y


## fooocus change -------------
def get_unet_to_diffusers_map():
    with open(os.path.join(ROOT_DIR, "../Fooocus/unet_to_diffusers_map.json")) as f:
        unet_to_diffusers_map = json.load(f)
    return unet_to_diffusers_map


def set_attr(obj, attr, value):
    attrs = attr.split(".")
    for name in attrs[:-1]:
        obj = getattr(obj, name)
    prev = getattr(obj, attrs[-1])
    setattr(obj, attrs[-1], torch.nn.Parameter(value, requires_grad=False))
    del prev


def load_fooocus_inpaint_patch_model_dict(device, fooocus_patch_weights_path):
    inpaint_patch_dict = torch.load(fooocus_patch_weights_path, map_location=device, pickle_module=checkpoint_pickle)
    return inpaint_patch_dict


def unload_fooocus_patch_layers(unet_model):
    assert hasattr(unet_model, "foocus_patch_backup_weights")
    backup = unet_model.foocus_patch_backup_weights

    device = unet_model.device
    model_state_dict = unet_model.state_dict()

    for k, v in backup.items():
        logger.debug(f"Unloading patch layer {k!r}")
        if k in model_state_dict:
            model_state_dict[k] = v.to(device)

    unet_model.load_state_dict(model_state_dict)

    unet_model.foocus_patch_backup_weights = {}
    logger.info("Unet model restored to original weights.")
    try:
        _ = gc.collect()
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()
    except Exception:
        pass
    return unet_model


def calculate_weight(patch_weights, weight, key, strength_patch, strength_model):
    if strength_model != 1.0:
        weight *= strength_model

    w1 = model_management.cast_to_device(patch_weights[0], weight.device, torch.float32)
    w_min = model_management.cast_to_device(patch_weights[1], weight.device, torch.float32)
    w_max = model_management.cast_to_device(patch_weights[2], weight.device, torch.float32)
    w1 = (w1 / 255.0) * (w_max - w_min) + w_min

    if strength_patch != 0.0:
        if w1.shape != weight.shape:
            logger.warning(f"WARNING SHAPE MISMATCH {key} FOOOCUS WEIGHT NOT MERGED {w1.shape} != {weight.shape}")
        else:
            weight += strength_patch * model_management.cast_to_device(w1, weight.device, weight.dtype)

    return weight


def patch_inpaint_layers_to_diffusers_unet(unet_model, strength_patch, strength_model, inpaint_patch_dict):
    assert hasattr(unet_model, "foocus_patch_backup_weights")

    unet_to_diffusers_map = get_unet_to_diffusers_map()
    unet_to_diffusers_map = {v: k for k, v in unet_to_diffusers_map.items()}
    

    unet_model_state_dict = unet_model.state_dict()
    unet_model.fooocus_patch_backup_weights = unet_model_state_dict

    flag = 1
    for inpaint_key, inpaint_weights in inpaint_patch_dict.items():
        if "diffusion_model." in inpaint_key:
            inpaint_key = inpaint_key[len("diffusion_model.") :]

        unet2diff_k1 = unet_to_diffusers_map[inpaint_key]
        unet2diff_k2 = (
            ".".join(unet_to_diffusers_map[inpaint_key].split(".")[0:-1])
            + ".base_layer."
            + unet_to_diffusers_map[inpaint_key].split(".")[-1]
        )
        if (unet2diff_k1 not in unet_model_state_dict) and (unet2diff_k2 not in unet_model_state_dict):
            logger.info(f"Diffusers unet key not found for the inpaint patch key = {inpaint_key}")
            flag = 0
        else:
            if unet2diff_k2 in unet_model_state_dict:
                diffuser_key = unet2diff_k2
            else:
                diffuser_key = unet2diff_k1

            logger.debug(f"Found inpaint patch key = {inpaint_key!r} with diffusers unet key = {diffuser_key!r}")

            original_weight = unet_model_state_dict[diffuser_key]
            unet_model.foocus_patch_backup_weights[diffuser_key] = copy.deepcopy(original_weight)

            temp_original_weight = model_management.cast_to_device(
                original_weight, original_weight.device, torch.float32, copy=True
            )
            out_weight = calculate_weight(
                inpaint_weights, temp_original_weight, diffuser_key, strength_patch, strength_model
            ).to(original_weight.dtype)
            set_attr(unet_model, diffuser_key, out_weight)
            del temp_original_weight
    if flag:
        logger.info(f"All keys of inpaint patch weights found and matched successfully with diffusers unet keys.")
    logger.info("Unet model updated with patch weights.")
    return unet_model


## fooocus change end ---------
