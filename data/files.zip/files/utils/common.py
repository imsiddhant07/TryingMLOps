import logging
import re
import time
from contextlib import contextmanager
from functools import wraps


def timing_decorator(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        logging.info(f"{func.__name__} took {elapsed_time:.2f} seconds to run.")
        return result

    return wrapper


@contextmanager
def timing_context(label=None):
    start_time = time.time()
    try:
        yield
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        label_text = f"{label} " if label is not None else ""
        logging.info(f"{label_text} took {elapsed_time:.2f} seconds to run.")


def strip_special_chars(s):
    """
    Removes all special characters from the given string, leaving only letters and numbers.

    Parameters:
    s (str): The input string from which to remove special characters.

    Returns:
    str: The string with all special characters removed.
    """
    return re.sub(r"[^a-zA-Z0-9]", "", s)
