from PIL import Image
from pydantic import BaseModel
from typing import List


class BaseInferenceOutput(BaseModel):
    images: List[Image.Image] = []
    nsfw_content_detected: List[bool] = []
    nsfw_content_score: List[str] = []

    class Config:
        arbitrary_types_allowed = True
