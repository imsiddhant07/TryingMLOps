from diffusers import (
    DPMSolverMultistepScheduler,
    DPMSolverSinglestepScheduler,
    EulerAncestralDiscreteScheduler,
    EulerDiscreteScheduler,
    LCMScheduler,
)
from enum import Enum


class SchedulerTypes(Enum):
    EulerAncestralDiscreteScheduler = "EULER-A"
    LCMScheduler = "LCM"
    DPMPlusPlus2MKarrasScheduler = "DPMPlusPlus2MKarras"
    DPMPlusPlusSDEKarrasScheduler = "DPMPlusPlusSDEKarras"
    DPMPlusPlus2MSDEKarrasScheduler = "DPMPlusPlus2MSDEKarras"
    DPMPlusPlusSDEScheduler = "DPMPlusPlusSDE"
    EulerDiscreteScheduler = "EULER"


SCHEDULER_TYPE_TO_CLASS = {
    SchedulerTypes.EulerAncestralDiscreteScheduler: EulerAncestralDiscreteScheduler,
    SchedulerTypes.LCMScheduler: LCMScheduler,
    SchedulerTypes.DPMPlusPlus2MKarrasScheduler: DPMSolverMultistepScheduler,
    SchedulerTypes.DPMPlusPlusSDEKarrasScheduler: DPMSolverSinglestepScheduler,
    SchedulerTypes.DPMPlusPlus2MSDEKarrasScheduler: DPMSolverMultistepScheduler,
    SchedulerTypes.DPMPlusPlusSDEScheduler: DPMSolverSinglestepScheduler,
    SchedulerTypes.EulerDiscreteScheduler: EulerDiscreteScheduler,
}

SCHEDULER_TYPE_TO_EXTRA_KWARGS = {
    SchedulerTypes.EulerAncestralDiscreteScheduler: {},
    SchedulerTypes.LCMScheduler: {},
    SchedulerTypes.DPMPlusPlus2MKarrasScheduler: {"use_karras_sigmas": True},
    SchedulerTypes.DPMPlusPlusSDEKarrasScheduler: {"use_karras_sigmas": True},
    SchedulerTypes.DPMPlusPlus2MSDEKarrasScheduler: {"algorithm_type": "sde-dpmsolver++", "use_karras_sigmas": True},
    SchedulerTypes.DPMPlusPlusSDEScheduler: {},
    SchedulerTypes.EulerDiscreteScheduler: {},
}


class ImageGenerationTypes(Enum):
    TXT_TO_IMG = "TXT_TO_IMG"
    IMG_TO_IMG = "IMG_TO_IMG"
    INPAINT = "INPAINT"
    FOOOCUS_INPAINT = "FOOOCUS_INPAINT"

    CONTROLNET_TXT_TO_IMG = "CONTROLNET_TXT_TO_IMG"
    CONTROLNET_IMG_TO_IMG = "CONTROLNET_IMG_TO_IMG"
    CONTROLNET_INPAINT = "CONTROLNET_INPAINT"
    CONTROLNET_FOOOCUS_INPAINT = "CONTROLNET_FOOOCUS_INPAINT"

    ADAPTER_TXT_TO_IMG = "ADAPTER_TXT_TO_IMG"
    ADAPTER_IMG_TO_IMG = "ADAPTER_IMG_TO_IMG"
    ADAPTER_INPAINT = "ADAPTER_INPAINT"


class PipelineStatusModes(str, Enum):
    STARTING = "starting"
    WAITING = "waiting"
    QUEUE_EMPTY = "queue_empty"
    TASK_RECEIVED = "task_received"

    INITIALIZING = "initializing"
    INITIALIZING_FAILED = "initializing_failed"
    INITIALIZING_SUCCESS = "initializing_success"

    INFERENCING = "inferencing"
    INFERENCING_FAILED = "inferencing_failed"
    INFERENCING_SUCCESS = "inferencing_success"


class GPUTypes(Enum):
    A100 = "A100"
    A10 = "A10"
    GTX4090 = "GTX4090"
    T4 = "T4"
    L4 = "L4"
    H100 = "H100"


class InpaintingFillTypes(Enum):
    FILL = "fill"
    ORIGINAL = "original"
    LATENT_NOISE = "latent_noise"
    LATENT_NOTHING = "latent_nothing"


class InpaintingFullResTypes(Enum):
    WHOLE_PICTURE = "whole_image"
    ONLY_MASKED = "only_masked"


class InpaintingMaskInvertTypes(Enum):
    INPAINT_MASKED = "inpaint_masked"
    INPAINT_NOT_MASKED = "inpaint_not_masked"


class ResizeModeTypes(Enum):
    JUST_RESIZE = "just_resize"
    CROP_AND_RESIZE = "crop_and_resize"
    RESIZE_AND_FILL = "resize_and_fill"
    JUST_RESIZE_LATENT_UPSCALE = "just_resize_latent_upscale"
