from pydantic import BaseModel
from typing import List


class Character(BaseModel):
    id: str
    name: str
    model: str
    imageURL: str
    gender: str
    metadata: str


class GetCharactersResponse(BaseModel):
    characters: List[Character]


class CharacterDetails(BaseModel):
    id: str
    name: str
    model: str
    diffusers_prompt: str
    webui_prompt: str
    file_name: str


class GetCharacterDetailsResponse(BaseModel):
    characters: List[CharacterDetails]
