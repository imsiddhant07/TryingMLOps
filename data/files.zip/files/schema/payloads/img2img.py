from schema.payloads.base import BaseRequest, BaseResponse


class Img2ImgRequest(BaseRequest):
    init_image: str = "https://content.dashtoon.ai/stability-images/be9117d5-fc7b-43d2-bcbb-1031083115d8.webp"
    strength: float = 0.75


class Img2ImgResponse(BaseResponse):
    pass
