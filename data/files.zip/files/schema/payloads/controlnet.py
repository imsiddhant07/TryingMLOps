from schema.common import InpaintingFillTypes, InpaintingFullResTypes
from schema.payloads.base import BaseRequest, BaseResponse
from typing import List


class ControlNetText2ImgRequest(BaseRequest):
    controlnet_images: List[str] = [
        "https://content.dashtoon.ai/stability-images/b9762eb7-a412-4eaa-8ad4-d99699305012.webp"
    ]
    controlnet_models: List[str] = ["controlnet-scribble"]
    controlnet_weights: List[float] = [0.5]


class ControlNetImg2ImgRequest(BaseRequest):
    init_image: str = "https://content.dashtoon.ai/stability-images/be9117d5-fc7b-43d2-bcbb-1031083115d8.webp"
    strength: float = 0.75
    controlnet_images: List[str] = [
        "https://content.dashtoon.ai/stability-images/b9762eb7-a412-4eaa-8ad4-d99699305012.webp"
    ]
    controlnet_models: List[str] = ["controlnet-scribble"]
    controlnet_weights: List[float] = [0.5]


class ControlNetInpaintRequest(BaseRequest):
    mask_image: str = "https://content.dashtoon.ai/user-uploaded-images/45194ac5-5040-4419-b497-a70185d3c4dc.png"
    init_image: str = "https://content.dashtoon.ai/stability-images/be9117d5-fc7b-43d2-bcbb-1031083115d8.webp"
    strength: float = 0.75
    controlnet_images: List[str] = [
        "https://content.dashtoon.ai/stability-images/b9762eb7-a412-4eaa-8ad4-d99699305012.webp"
    ]
    controlnet_models: List[str] = ["controlnet-scribble"]
    controlnet_weights: List[float] = [0.5]
    inpaint_type: str = InpaintingFullResTypes.ONLY_MASKED.value
    inpaint_fill_type: str = InpaintingFillTypes.ORIGINAL.value


class ControlNetText2ImgResponse(BaseResponse):
    pass


class ControlNetImg2ImgResponse(BaseResponse):
    pass


class ControlNetInpaintResponse(BaseResponse):
    pass
