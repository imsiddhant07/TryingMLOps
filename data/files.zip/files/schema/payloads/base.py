import uuid
from pydantic import BaseModel
from custom.schema.common import GPUTypes, SchedulerTypes
from typing import List, Optional


class CharacterDetailsRequest(BaseModel):
    id: str = ""
    name: str
    weight: float
    file_name: str = ""


class StyleDetailsRequest(BaseModel):
    id: str = ""
    name: str
    weight: float
    filePath: str = ""


class BaseRequest(BaseModel):
    generationId: str = str(uuid.uuid4())
    prompt: str = "a cute cat"
    negative_prompt: str = ""
    width: int = 1024
    height: int = 1024
    cfg: float = 7.5
    seed: int = -1
    num_inference_steps: int = 20
    num_images_per_prompt: int = 4
    character: List[CharacterDetailsRequest] = []
    style: List[StyleDetailsRequest] = []
    textual_inversion: List[str] = []
    token_merging_ratio: Optional[float] = None
    scheduler: Optional[str] = SchedulerTypes.EulerAncestralDiscreteScheduler.value


class BaseResponse(BaseModel):
    generationId: str = ""
    images: List[str] = []
    nsfw_map: List[bool] = []
    nsfw_score: List[str] = []
    status: str = "SUCCESS"
    inference_time: float = 0.0
    gpu_type: GPUTypes = GPUTypes.GTX4090
    content_type: str = "image/png"
    file_extension: str = "png"
