from schema.common import InpaintingFillTypes, InpaintingFullResTypes
from schema.payloads.base import BaseRequest, BaseResponse


class InpaintRequest(BaseRequest):
    init_image: str = "https://content.dashtoon.ai/stability-images/be9117d5-fc7b-43d2-bcbb-1031083115d8.webp"
    mask_image: str = "https://content.dashtoon.ai/user-uploaded-images/45194ac5-5040-4419-b497-a70185d3c4dc.png"
    strength: float = 0.75
    inpaint_type: str = InpaintingFullResTypes.ONLY_MASKED.value
    inpaint_fill_type: str = InpaintingFillTypes.ORIGINAL.value
    clip_skip: bool = False


FooocusInpaintRequest = InpaintRequest


class InpaintResponse(BaseResponse):
    pass
