from schema.payloads.base import BaseRequest, BaseResponse
from typing import Optional


class Text2ImageRequest(BaseRequest):
    pass


class Text2ImageResponse(BaseResponse):
    pass
