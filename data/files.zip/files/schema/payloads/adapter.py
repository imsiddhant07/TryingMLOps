from schema.payloads.base import BaseResponse
from schema.payloads.controlnet import ControlNetImg2ImgRequest, ControlNetInpaintRequest, ControlNetText2ImgRequest
from typing import List


class AdapterText2ImgRequest(ControlNetText2ImgRequest):
    adapter_models: List[str]


class AdapterImg2ImgRequest(ControlNetImg2ImgRequest):
    adapter_models: List[str]


class AdapterInpaintRequest(ControlNetInpaintRequest):
    adapter_models: List[str]


class AdapterText2ImgResponse(BaseResponse):
    pass


class AdapterImg2ImgResponse(BaseResponse):
    pass


class AdapterInpaintResponse(BaseResponse):
    pass
