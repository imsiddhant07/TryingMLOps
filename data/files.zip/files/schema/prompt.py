from pydantic import BaseModel
from schema.common import ImageGenerationTypes, SchedulerTypes
from typing import Any, List, Optional, Union


class BaseDetails(BaseModel):
    name: str
    path: str


class BaseDetailsWithWeight(BaseModel):
    id: Optional[str] = None
    name: str
    path: str
    weight: Optional[float] = None


class CharacterDetails(BaseModel):
    characters: List[BaseDetailsWithWeight] = []


class StyleDetails(BaseModel):
    styles: List[BaseDetailsWithWeight] = []


class TextualInversionDetails(BaseModel):
    textualinversions: List[BaseDetails] = []


class Prompt(BaseModel):
    uuid: str
    type: Union[ImageGenerationTypes, str] = ImageGenerationTypes.TXT_TO_IMG
    prompt: str
    negative_prompt: Optional[str] = None
    width: int
    height: int
    cfg: float
    seed: int
    num_inference_steps: int
    num_images_per_prompt: int
    noise_strength: float = 0.75
    fix_face: bool = False
    mask_image: Optional[Any] = None
    init_image: Optional[Any] = None
    base_model: Optional[BaseDetails] = None
    character: Optional[CharacterDetails] = None
    style: Optional[StyleDetails] = None
    controlnet_images: Optional[List[Any]] = None
    controlnet_models: Optional[List[str]] = None
    controlnet_weights: Optional[List[float]] = None
    adapter_models: Optional[List[str]] = None
    textual_inversion: Optional[TextualInversionDetails] = None
    token_merging_ratio: Optional[float] = None
    clip_skip: bool = False
    high_res_fix: bool = False
    high_res_fix_denoise: Optional[float] = None
    inpaint_type: Optional[str] = None
    inpaint_fill_type: Optional[str] = None
    scheduler: Optional[SchedulerTypes] = SchedulerTypes.EulerAncestralDiscreteScheduler
